from .models import JobSeeker, Employeer, JobPost
from rest_framework import serializers
from user_auth.serializers import UserSerializer

from enum import Enum
class StatusEnum(Enum):
    ENABLE = "enable"
    DISABLE = "disable"

class JobSeekerSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    class Meta:
        model = JobSeeker 
        fields = "__all__" # all fields name

class EmployeerSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    dob = serializers.DateField(format="%Y-%m-%d") 
    class Meta:
        model = Employeer 
        fields = "__all__" # all fields name
        

class JobPostSerializerWithSalary(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    status = serializers.ChoiceField(choices=[(tag, tag.value) for tag in StatusEnum], read_only=True)
    class Meta:
        model =  JobPost
        fields = "__all__" # all fields name

    def create(self, validated_data):
        return JobPost.objects.create(**validated_data, user=self.context["request"].user)
    
class JobPostSerializerWithoutSalary(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    status = serializers.ChoiceField(choices=[(tag, tag.value) for tag in StatusEnum], read_only=True)
    class Meta:
        model =  JobPost
        fields = ["job_title", "job_description", "required_skills", "status", "user"]