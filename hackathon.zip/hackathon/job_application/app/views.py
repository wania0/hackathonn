from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from rest_framework.request import Request
from rest_framework.generics import CreateAPIView, UpdateAPIView
from rest_framework.viewsets import ModelViewSet
from rest_framework.decorators import action, api_view
from .permissions import IsEmployer

from .models import JobSeeker, Employeer, JobPost
from .serializers import JobSeekerSerializer, EmployeerSerializer, JobPostSerializerWithSalary, JobPostSerializerWithoutSalary
  
# class JobSeekerGenericCreateUpdateApiView(CreateAPIView, UpdateAPIView):
#     queryset = JobSeeker.objects.all()
#     serializer_class =JobSeekerSerializer
    
class EmployeerGenericCreateUpdateApiView(CreateAPIView,UpdateAPIView):
    queryset = Employeer.objects.all()
    serializer_class = EmployeerSerializer

    def create(self, request, *args, **kwargs): # works before serializer validation

        if  Employeer.objects.filter(user=self.request.user).exists():
            print("user exists")
            return Response("already-created", status= status.HTTP_406_NOT_ACCEPTABLE)

        return super().create(request, *args, **kwargs)

    def perform_create(self, serializer): # works after serializer validation
        return Employeer.objects.create(user=self.request.user, **serializer.validated_data)


class JobPostModelViewSet(ModelViewSet):
    queryset = JobPost.objects.all()
    serializer_class = JobPostSerializerWithoutSalary
    def get_permissions(self):
        if self.action == "create":
            return [IsEmployer()]
        return super().get_permissions()
    
    
# each employeer can see only its own jobpost
    @action(detail=False, methods=["get"])
    def my_jobposts(self, request):
        user = self.request.user
        queryset = JobPost.objects.filter(user=user)
        serializer = JobPostSerializerWithSalary(queryset, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=["put"])
    def update_jobpost(self, request, pk=id):
        print("Update")
        jobpost = JobPost.objects.get(id=pk)
        if jobpost.status == 1:
            jobpost.status = 0
        else:
            jobpost.status = 1
        jobpost.save()
        print("before ersponse")
        return Response("success")
    
    def get_serializer_class(self):
        if self.request.user.is_authenticated:
            return JobPostSerializerWithSalary
        else:
            return JobPostSerializerWithoutSalary