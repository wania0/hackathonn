from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import EmployeerGenericCreateUpdateApiView, JobPostModelViewSet


router = DefaultRouter()
router.register("job-post", JobPostModelViewSet)

urlpatterns = [
    path('employeer/profile/', EmployeerGenericCreateUpdateApiView.as_view()),


] + router.urls

